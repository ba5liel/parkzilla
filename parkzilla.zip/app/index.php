<html>
<head>
  <meta charset="UTF-8"/>
  <meta name= "viewport" content = "width = device-width, initial-scale = 1.0"/>
  <link rel = "stylesheet" type = "text/css" href = "../css/bootstrap.css"/>
  <link rel = "stylesheet" type = "text/css" href = "css.css"/>
  <link rel="stylesheet" type="text/css" href="../css/Font-Awesome/css/font-awesome.min.css"/>
  <title>
    download app
  </title>
  <script>
    function reDir(x){
      window.location.assign('download.php?q='+ x);
    }
    </script>
</head>
<body>
  <center>
  <div class="dow win">
    <img onclick="reDir('a.mp4')" alt="windows" src="win.png"/>
    <span onclick="reDir('a.mp4')">Download <i class="fa fa-windows"></i></span>
  </div>
  <div class="dow win app">
    <img onclick="reDir('b.mp4')" alt="apple" src="apple.png"/>
    <span onclick="reDir('b.mp4')">Download <i class="fa fa-apple"></i></span>
  </div>
  <div class="dow win and">
    <img onclick="reDir('parkzilla.apk')" alt="andriod" src="and.png"/>
    <span onclick="reDir('parkzilla.apk')">Download <i class="fa fa-android"></i></span>
  </div>
</center>
<div class="clearfix"></div>
  <img id="phone" alt="phone" src="phone.jpg"/>
  <img id="parking" alt="parking" src="oark.jpg"/>
  <div class="thenW">
    plase  Lorem ipsum dolor sit amet, consectetur adipiscing elit.
        Pellentesque sit vasdsd amet lorem ligula dolor sit amet, consectetur adipiscing elit.
            Pellentesque sit amet lorem Pellentesque sit amet lorem ligula sit amet, consectetur adipiscing elit.
                Pellentesque sit amet lorem ligula dolor sit amet, consectetur adipiscing elit.
                    Pellentesque sit amet lorem Pellentesque sit amet lorem ligula.
  </div>
</body>
</html>
